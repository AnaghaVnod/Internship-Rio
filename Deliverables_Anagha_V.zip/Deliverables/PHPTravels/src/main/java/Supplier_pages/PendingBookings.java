package Supplier_pages;
import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PendingBookings {
	WebDriver driver;

	public PendingBookings(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="(//select[@id='booking_status'])[1]")
	private WebElement bookingStatus1;
	
	@FindBy(xpath="(//div[text()='Dashboard'])")
	private WebElement dashboard;
	
	
	public void changeStatus(String changedStatus) throws InterruptedException {
		
		Select drpStatus = new Select(bookingStatus1);
		drpStatus.selectByVisibleText(changedStatus);
		Thread.sleep(2000);
	}
	public void goDashboard() {
		dashboard.click();
	}

}
