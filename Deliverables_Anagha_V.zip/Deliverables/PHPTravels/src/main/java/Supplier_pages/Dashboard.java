package Supplier_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Dashboard {
	WebDriver driver;

	public Dashboard(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//div[text()='Sales overview & summary']")
	private WebElement dashtext;
	
	@FindBy(xpath="//h2[text()='Revenue Breakdown 2023']")
	private WebElement revenuetext;
	
	@FindBy(xpath="(//div[@class='display-5'])[1]")
	private WebElement confirmedBookings;
	
	@FindBy(xpath="(//div[@class='display-5'])[2]")
	private WebElement pendingBookings;
	
	@FindBy(xpath="//div[text()='Cancelled Bookings']")
	private WebElement cancelledBookings;
	
	@FindBy(xpath="//a[@aria-controls='toursmodule']")
	private WebElement tours;
	
	@FindBy(xpath="//div[@id='toursmodule']")
	private WebElement tours2;
	
	
	@FindBy(xpath="//i[text()='flights']")
	private WebElement flights;
	
	@FindBy(xpath="//a[text()='Bookings']")
	private WebElement bookings;
	
	
	@FindBy(xpath="//a[text()='Manage Tours']")
	private WebElement manageTours;
	
	
	
	public boolean textVisible() {
		boolean bool=dashtext.isDisplayed();
		return bool;
	}
	public boolean revenueVisible() {
		boolean bool=revenuetext.isDisplayed();
		return bool;
	}
	public void clickPending() {
		pendingBookings.click();
	}
	public void clickConfirmed() {
		confirmedBookings.click();
	}
	public int getTextConfirmed() {
		String conf=confirmedBookings.getText();
		int c =Integer.valueOf(conf);
		return c;
	}
	public int getTextPending() {
		String pend=pendingBookings.getText();
		int p =Integer.valueOf(pend);
		return p;
		
	}
	public int newTextConfirmed() {
		String newconf=confirmedBookings.getText();
		int nc=Integer.valueOf(newconf);
		return nc;
	}
	public int newTextPending() {
		String newpend=pendingBookings.getText();
		int np=Integer.valueOf(newpend);
		return np;
		
	}
	public void verifyTours() {
		tours.click();
		tours2.click();
		manageTours.click();
		
	}
    public String verifyToursModule() {
	   
	   String title=driver.getTitle();
	   return title;
    }   
    public void verifyBookings() {
    	bookings.click();
    }
    public String verifyBookingsModule() {
    	String btitle=driver.getTitle();
 	   return btitle;
    }
    
}
