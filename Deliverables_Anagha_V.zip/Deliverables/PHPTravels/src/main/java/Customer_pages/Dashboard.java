
package Customer_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class Dashboard {
	
	WebDriver driver;

	public Dashboard(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="(//a[text()=' My Bookings'])[2]")
	private WebElement myBookings;
	
	@FindBy(xpath="(//a[text()=' Add Funds'])[2]")
	private WebElement addFunds;

	@FindBy(xpath="(//a[text()=' My Profile'])[2]")
	private WebElement myProfiles;

	@FindBy(xpath="(//a[text()=' Logout'])[2]")
	private WebElement logout;
	
	public String verifyMyBookings() {
		myBookings.click();
		String actualTitle=driver.getTitle();
		return actualTitle;
		
	}

	public void verifyAddFunds() {
		addFunds.click();
	}
	public void verifymyProfiles() {
		myProfiles.click();
	}
	public void verifymyLogout() {
		logout.click();
		
	}
}
