package Customer_pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddFunds {
	WebDriver driver;

	public AddFunds(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(className="title")
	private WebElement ftitle;
	
	@FindBy(id="gateway_razorpay")
	private WebElement razor;
	
	@FindBy(id="gateway_stripe")
	private WebElement stripe;
	
	@FindBy(id="gateway_paypal")
	private WebElement paypal;
	
	@FindBy(id="gateway_bank-transfer")
	private WebElement bank;
	
	@FindBy(name="price")
	private WebElement price;
	
	@FindBy(xpath="//button[text()='Pay Now ']")
	private WebElement payNow;
	
	@FindBy(xpath="(//div[@aria-label='PayPal'])[2]")
	private WebElement paypal2;
	
	
	public boolean verifyAddFunds() {
    boolean bool=ftitle.isDisplayed();
    return bool;
	}
	public void selectPaypal(){
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",paypal);
		//Actions action=new Actions(driver);
		//action.moveToElement(paypal);
		//action.click();
		
		
	}
	public void enterAmount(String amount) {
		price.clear();
		price.sendKeys(amount);
	}
	public void clickPayNow() throws InterruptedException{
		payNow.submit();
		Thread.sleep(2000);
	}
	public boolean verifyPaypalWindow(){
		boolean bool=paypal2.isDisplayed();
		return bool;
		
	}

}