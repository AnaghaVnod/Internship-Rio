package Customer_pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Profile {
	WebDriver driver;

	public Profile(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(name="firstname")
	private WebElement firstName;

	@FindBy(name="lastname")
	private WebElement lastName;

	@FindBy(name="phone")
	private WebElement phone;

	@FindBy(name="email")
	private WebElement email;

	@FindBy(name="password")
	private WebElement password;
	
	@FindBy(id="pselect2-from_country-container")
	private WebElement country;
	
	@FindBy(name="state")
	private WebElement state;
	
	@FindBy(name="city")
	private WebElement city;

	@FindBy(name="fax")
	private WebElement fax;
	
	@FindBy(name="zip")
	private WebElement zip;
	
	@FindBy(name="address1")
	private WebElement address1;
	
	@FindBy(name="address2")
	private WebElement address2;
	
	@FindBy(xpath="//button[text()='Update Profile']")
	private WebElement updateProfile;
	
	public void enterFirstName(String firstname) {
		firstName.sendKeys(firstname);
	}
	public void enterLastName(String lastname) {
		lastName.sendKeys(lastname);
	}
	public void enterPhone(String phone2) {
		phone.sendKeys(phone2);
	}
	public void enterEmail(String emailId) {
		email.sendKeys(emailId);
	}
	public void enterPassword(String passWord) {
		password.sendKeys(passWord);
	}
	public void enterCountry(String countryName) {
		country.sendKeys(countryName);
		country.sendKeys(Keys.ENTER);
	}	
	public void enterState(String stateName) {
		state.sendKeys(stateName);	
	}
	public void enterCity(String cityName) {
		city.sendKeys(cityName);	
	}
	public void enterFax(String faxNum) {
		fax.sendKeys(faxNum);	
	}
	public void enterPIN(String pinNum) {
		zip.sendKeys(pinNum);	
	}
	public void enterAddress1(String addr1) {
		address1.sendKeys(addr1);	
	}
	public void enterAddress2(String addr2) {
		address2.sendKeys(addr2);	
	}
	public void clickUpdate() {
		updateProfile.click();
	}
	
}
