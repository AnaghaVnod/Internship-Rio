package Customer_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Bookings {
	WebDriver driver;

	public Bookings(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="(//a[text()=' View Voucher'])[1]")
	private WebElement viewVoucher;
	
	@FindBy(id="download")
	private WebElement download;
	
	@FindBy(xpath="//input[@value='Request Cancellation']")
	private WebElement cancel;
	

	@FindBy(xpath="//h3[text()='My Bookings']")
	private WebElement bookings;
	

	public Boolean verifyBookings() {
		Boolean actual=bookings.isDisplayed();
		return actual;
	}
	
	
	public void clickVoucher() throws InterruptedException {
		String originalWindow=driver.getWindowHandle();
		viewVoucher.click();
		Thread.sleep(3000);
		
	}
	public String verifyViewVoucher() {
	
		for(String winHandle:driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		
		String invoice=driver.getTitle();
		return invoice;
		//driver.close();
	}

}
