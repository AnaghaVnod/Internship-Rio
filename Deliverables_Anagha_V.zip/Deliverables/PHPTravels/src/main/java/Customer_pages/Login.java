package Customer_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Login  {
	WebDriver driver;

	public Login(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="(//input[@name='email'])[1]")
	private WebElement email;
	
	@FindBy(name="password")
	private WebElement password;
	
	@FindBy(xpath="//span[text()='Login']")
	private WebElement login;
	
	public void validDetails(String validEmail,String validPassword) {
		email.sendKeys(validEmail);
		password.sendKeys(validPassword);
	}
	public void invalidPass(String validEmail,String invalidPassword) {
		email.sendKeys(validEmail);
		password.sendKeys(invalidPassword);
	}
	public void invalidDetails(String invalidusername,String invalidpassword) {
		email.sendKeys(invalidusername);
		password.sendKeys(invalidpassword);
	}
	public void invalidUser(String invalidEmail,String validPassword) {
		email.sendKeys(invalidEmail);
		password.sendKeys(validPassword);
	}
	public void clickLogin() {
		login.click();
		
	}
	public String verifylogin() {
		String title=driver.getTitle();
				return title;
	}
}
