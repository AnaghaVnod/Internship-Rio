package Admin_pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CancelledBookings {

WebDriver driver;

public CancelledBookings(WebDriver driver)
{
	this.driver=driver;
	PageFactory.initElements(driver, this);	
}

   @FindBy(xpath="(//select[@id='booking_status'])[1]")
   private WebElement bookingStatus;
   
   @FindBy(xpath="(//i[@class='fa fa-times'])[1]")
   private WebElement deleteBooking;
   
   @FindBy(xpath="(//div[@class='display-5'])[3]")
   private WebElement numCancelled;
   
   public int getNumCancelled() {
	   String cancel=numCancelled.getText();
	   int c=Integer.valueOf(cancel);
	   return c;
   }
	   
   public void deleteBooking() throws InterruptedException {
	   JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",deleteBooking);
	  // deleteBooking.click();
	   Thread.sleep(1000);
	   driver.switchTo().alert().accept();
	   Thread.sleep(1000);
   }
  
   
   public int newNumCancelled() {
	   String newcancel=numCancelled.getText();
	   int nc=Integer.valueOf(newcancel);
	   return nc;
   }
	
   }
   