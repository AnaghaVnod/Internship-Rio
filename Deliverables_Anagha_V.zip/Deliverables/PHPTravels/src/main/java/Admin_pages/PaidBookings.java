package Admin_pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaidBookings {

WebDriver driver;

public PaidBookings (WebDriver driver)
 {
	this.driver=driver;
	PageFactory.initElements(driver, this);	
 }

    @FindBy(xpath="(//select[@id='booking_status'])[1]")
    private WebElement bookingStatus;
  
    @FindBy(xpath="(//a[text()='   Invoice'])[1]")
    private WebElement invoice;

    public void clickInvoice() throws InterruptedException {
    	JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",invoice);
	//invoice.click();
		Thread.sleep(2000);
 }
    public String verifyInvoice() {

     for(String winHandle:driver.getWindowHandles()) {
	    driver.switchTo().window(winHandle);
     }
	    String inVoice=driver.getTitle();
		return inVoice;
    
 }
}


