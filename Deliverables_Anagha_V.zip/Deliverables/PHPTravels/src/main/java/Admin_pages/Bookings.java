package Admin_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Bookings {

WebDriver driver;

public Bookings(WebDriver driver)
{
	this.driver=driver;
	PageFactory.initElements(driver, this);	
}
    @FindBy(xpath="//div[text()='Confrimed Bookings']")
    private WebElement confirmedBookings;

    @FindBy(xpath="//div[text()='Pending Bookings']")
    private WebElement pendingBookings;

    @FindBy(xpath="//div[text()='Cancelled Bookings']")
    private WebElement cancelledBookings;

    @FindBy(xpath="//div[text()='Paid Bookings']")
    private WebElement paidBookings;

    @FindBy(xpath="//div[text()='Unpaid Bookings']")
    private WebElement unpaidBookings;

    @FindBy(xpath="//div[text()='Refunded Bookings']")
    private WebElement refundedBookings;

    public void clickPaid() {
	   paidBookings.click();
    }
    public void clickCancelled() {
       cancelledBookings.click();
    }

   

}
