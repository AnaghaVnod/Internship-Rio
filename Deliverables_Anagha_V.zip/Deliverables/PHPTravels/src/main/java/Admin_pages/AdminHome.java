package Admin_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminHome{

WebDriver driver;

public AdminHome(WebDriver driver)
{
	this.driver=driver;
	PageFactory.initElements(driver, this);	
}

   @FindBy(xpath="(//a[text()='Bookings'])[1]")
   private WebElement bookings;
   

   @FindBy(xpath="(//a[text()='Website'])[1]")
   private WebElement website;
   
   
   @FindBy(xpath="(//a[text()='Docs'])[1]")
   private WebElement docs;
   

   @FindBy(xpath="//div[text()='Confrimed Bookings']")
   private WebElement confirmedBookings;

   @FindBy(xpath="//div[text()='Pending Bookings']")
   private WebElement pendingBookings;

   @FindBy(xpath="//div[text()='Cancelled Bookings']")
   private WebElement cancelledBookings;

   @FindBy(xpath="//div[text()='Paid Bookings']")
   private WebElement paidBookings;

   @FindBy(xpath="//div[text()='Unpaid Bookings']")
   private WebElement unpaidBookings;

   @FindBy(xpath="//div[text()='Refunded Bookings']")
   private WebElement refundedBookings;

   public void clickPend() {
	   pendingBookings.click();
   }
   
   public void clickWebsite() throws InterruptedException {
	   String originalWindow=driver.getWindowHandle();
	   website.click();
	   Thread.sleep(2000);
   }
   
   public void verfybookings()  {
	   
	   bookings.click();
	   

   }
   public String verifyWebsite() {
  

	for(String winHandle:driver.getWindowHandles()) {
		driver.switchTo().window(winHandle);
	}
	
	String webSite=driver.getTitle();
	return webSite;
   }
   
}
