package Agent_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Home {
	WebDriver driver;

	public Home(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//a[text()='Hotels']")
	private WebElement hotels;
	
	@FindBy(xpath="//a[text()='flights']")
	private WebElement flights;
	
	@FindBy(xpath="//a[text()='Tours']")
	private WebElement tours;
	
	@FindBy(xpath="//a[text()='Transfers']")
	private WebElement transfers;
	
	@FindBy(xpath="//a[text()='visa']")
	private WebElement visa;
	
	@FindBy(xpath="//a[text()='Blog']")
	private WebElement blog;
	
	@FindBy(xpath="//a[text()='Offers']")
	private WebElement offers;
	
	@FindBy(xpath="(//a[text()='Company '])[1]")
	private WebElement company;
	
	@FindBy(xpath="(//a[text()='How to Book'])[1]")
	private WebElement howtoBook;
	
	@FindBy(xpath="(//a[text()='Last minute deals'])[1]")
	private WebElement lastMinDetails;
	
	@FindBy(id="currency")
	private WebElement currency;
	
	@FindBy(xpath="//a[text()=' INR']")
	private WebElement inr;
	
	@FindBy(xpath="(//a[text()=' My Bookings'])[2]")
	private WebElement myBookings;
	
	@FindBy(xpath="(//a[text()=' Add Funds'])[2]")
	private WebElement addFunds;

	@FindBy(xpath="(//a[text()=' My Profile'])[2]")
	private WebElement myProfiles;

	@FindBy(xpath="(//a[text()=' Logout'])[2]")
	private WebElement logout;
	
	public void verifyMyBookings() {
		myBookings.click();
	
		
	}

	public void verifyAddFunds() {
		addFunds.click();
		
	}
	public void verifymyProfiles() {
		myProfiles.click();
		
	}
	public void verifymyLogout() {
		logout.click();
		
	}
	
	public String verifyHotel() {
		hotels.click();
		String htitle=driver.getTitle();
		return htitle;
		
	}
    public String verifyFlights() {
		flights.click();
		String ftitle=driver.getTitle();
		return ftitle;
	}
    public String verifyTours() {
		tours.click();
		String ttitle=driver.getTitle();
		return ttitle;
	}
    public String verifyVisa() {
		visa.click();
		String vtitle=driver.getTitle();
		return vtitle;
	}
    public String verifyBlog() {
    	blog.click();
    	String btitle=driver.getTitle();
		return btitle;
	
    }
    public String verifyOffers() {
    	offers.click();
    	String otitle=driver.getTitle();
		return otitle;
	
    }
    public void changeCurrency() throws InterruptedException {
    	currency.click();
    	Thread.sleep(2000);
    	JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",inr);
    	//driver.findElement(By.xpath("//a[text()=' INR']")).submit()
    	//Select drpCurrency=new Select(currency);
    	//drpCurrency.selectByVisibleText(type);
    	
    }
    public String verifyChangeCurrency() {
    	String newCurr=currency.getText();
    	return newCurr;
    }
	
}
