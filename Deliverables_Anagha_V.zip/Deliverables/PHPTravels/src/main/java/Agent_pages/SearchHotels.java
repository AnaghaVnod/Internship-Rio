package Agent_pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchHotels {
	WebDriver driver;

	public SearchHotels(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//span[@title=' Search by City']")
	private WebElement searchTitle;
	

	@FindBy(xpath="//input[@role='searchbox']")
	private WebElement searchBox;
	
	
	@FindBy(id="checkin")
	private WebElement checkin;
	
	@FindBy(id="checkout")
	private WebElement checkout;
	
	@FindBy(xpath="//span[@class='guest_hotels']")
	private WebElement addroom;
	
	@FindBy(xpath="(//button[@id='submit'])[1]")
	private WebElement search;
	
	public void enterDetails(String cityName) throws InterruptedException {
		searchTitle.click();
		searchBox.sendKeys(cityName);
		Thread.sleep(3000);
		searchBox.sendKeys(Keys.ENTER);
	}
	public void clickSearch() {
		search.click();
	}
	public String verifySearch() {
		String stitle=driver.getTitle();
		return stitle;
	}

}
