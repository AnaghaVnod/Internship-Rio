package StepDefinitions;
import  org.junit.Assert;



import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Customer_pages.Login;
import Supplier_pages.Dashboard;
import Supplier_pages.PendingBookings;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierBack {
	WebDriver driver=null;
	Login objLogin;
	Dashboard objDash;
	PendingBookings objPend;
	
	public volatile int p,c,np,nc;
	
	 
	   @Given("Supplier is on login page")
	   
	   public void supplierLogin() throws InterruptedException {
		   driver=new ChromeDriver();
		   
		   driver.manage().window().maximize();	
		   driver.navigate().to("https://phptravels.net/supplier");
		   Thread.sleep(3000);
		   objLogin=new Login(driver);
		   objDash=new Dashboard(driver);
		   objPend=new PendingBookings(driver);
	   }


		   
	   @Given("Supplier enters valid email and password")
	   
		public void supplierValid() throws IOException {
		   
			objLogin.validDetails("supplier@phptravels.com","demosupplier");
			   
			}
	   
	   @Given("^Supplier enters \"([^\"]*)\" or \"([^\"]*)\"$")
		public void supplierInvalid(String invalidusername,String invalidpassword) throws IOException {
				
			objLogin.invalidDetails(invalidusername,invalidpassword);
	   }
			
		@When("Supplier clicks on login")
		public void supplierLoginVerify() throws InterruptedException {
			objLogin.clickLogin();
			Thread.sleep(2000);
			
		}
		
		
		@Then("Supplier navigates to dashboard page")
		public void verifySupplierLogin() {
			String actTitle=objLogin.verifylogin();
			String expTitle="Dashboard";
			Assert.assertEquals(expTitle, actTitle);
			driver.quit();
			
		}
 
		@Then("Supplier not navigated to dashboard page")	
		public void verifyInvalidLogin() {
			
		String actTitle=objLogin.verifylogin();
		String expTitle="Supplier Login";
		Assert.assertEquals(expTitle, actTitle);
		driver.quit();
	   }
		@Given("Supplier is on dashboard page")
		public void supplierLogged() throws InterruptedException {
			
			objLogin.validDetails("supplier@phptravels.com","demosupplier");
			objLogin.clickLogin();
			Thread.sleep(2000);
		
			 p=objDash.getTextPending();
			 c=objDash.getTextConfirmed();
			
			
		}
		@Then("Supplier can see sales overview and summary")
		public void salesOverview() {
			objDash.textVisible();
			driver.quit();
			
		}
		@Then("Supplier can see revenue breakdown")
		public void revenueBreakdown() {
			objDash.revenueVisible();
			driver.quit();
			
		}
		@And("Supplier clicks on pending booking")
		public void pendingBooking() {
			objDash.clickPending();
		}
		 @When("Supplier changes booking status from pending to confirmed")
		 public void changeBookingStatus() throws InterruptedException {
			 objPend.changeStatus("Confirmed");
		 }
		 @Then("The count is updated in dashboard")
		 public boolean checkCount() {
			 objPend.goDashboard();
			 nc=objDash.newTextConfirmed();
			 np=objDash.newTextPending();
			 	 
			 if(nc==c++&&p==np++) {
				 
				boolean bool=true;
				return bool;
				
			 }
			 else  {
				 System.out.println("fail");
			return false;
			 }	 
			 
		 }
		    @When("Supplier clicks on tours module")
		    public void verifyToursModule() {
		    	objDash.verifyTours();
		    	
		    }
		    @Then("Tours window is displayed")
		    public void verifyTours() {
		    	objDash.verifyToursModule();
		    	driver.quit();
		    }
		
		    @When("Supplier clicks on Bookings module")
		    public void verifyBookings() {
		    	objDash.verifyBookings();
		    	
		    }
		    @Then("Supplier navigated to Bookings window")
             public void verifyBookingsModule() {
		    	String act=objDash.verifyBookingsModule();
		    	String exp="Manage Bookings";
		    	Assert.assertEquals(act,exp);
            	driver.quit();
             }
		  
		   
}
