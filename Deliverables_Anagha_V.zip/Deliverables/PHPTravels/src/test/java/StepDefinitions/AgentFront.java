package StepDefinitions;

import java.io.IOException;


import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Agent_pages.Home;
import Agent_pages.SearchHotels;
import Customer_pages.Login;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class AgentFront {
	WebDriver driver=null;
	Login objLogin;
	Home objHome;
	SearchHotels objSearchHot;

	 
	   @Given("^Agent is on login page$")
		public void loginPage() throws InterruptedException {
		    driver=new ChromeDriver();
		    driver.manage().window().maximize();	
			driver.navigate().to("https://phptravels.net/login");
			Thread.sleep(3000);
			objLogin=new Login(driver);
	   }
		   
	   @When("Agent enters valid username and valid password")
		public void customerValid() throws IOException {
		    
			objLogin.validDetails("agent@phptravels.com","demoagent");
			//driver.quit();
			   
			}
	   @When("^Agent enters \"([^\"]*)\" or \"([^\"]*)\"$")
		public void agentInvalidUser(String invalidusername,String invalidpassword) throws IOException {
				
			objLogin.invalidDetails(invalidusername,invalidpassword);
	   }
	   @And("Agent clicks login")
		public void clickLogin() throws InterruptedException {
		
		    objLogin.clickLogin();
		    //driver.quit();
		       
		}
	   @Then("Agent navigated to dashboard page")
		public void verifyLogin() throws InterruptedException {
		    Thread.sleep(3000);
		    String actual=driver.getTitle();
		    String expTitle="Dashboard - PHPTRAVELS";
		    Assert.assertEquals(expTitle, actual);
		    driver.quit();
		   
		}

	    @Then("Agent not logged in")
		public void verifyError() {
	    	String title=driver.getTitle();
	    	String expected="Login - PHPTRAVELS";
	        Assert.assertEquals(title,expected);
			driver.quit();
	    }
	    @Given("Agent is on dashboard page")
	    public void agentLogged() {
	    	driver=new ChromeDriver();
			driver.manage().window().maximize();	
	    	driver.navigate().to("https://phptravels.net/login");
	    	objLogin=new Login(driver);
	    	objHome=new Home(driver); 
			objSearchHot=new SearchHotels(driver);
	    	objLogin.validDetails("agent@phptravels.com","demoagent");
	    	objLogin.clickLogin();
	    	
	    }
	    @And("Agent clicks on Hotels")
	    public void searchHotels() {
	    	String htitle=objHome.verifyHotel();
	    	Assert.assertEquals("Search Hotels - PHPTRAVELS", htitle);
	    }
	    @When("Agent enters search hotel details and proceed")
	    public void searchHotelDetails() throws InterruptedException {
	    	String cityName="Dubai";
	    	objSearchHot.enterDetails(cityName);
	    	objSearchHot.clickSearch();
	    }
	    
	    @Then("Hotel search results are displayed")
	    public void verifySearchResult() {
	    	String stitle=objSearchHot.verifySearch();
	    	Assert.assertEquals("Hotels in dubai - PHPTRAVELS", stitle);
	    	driver.quit();
	    }
	   
	    @When("Agent changes curreny from USD to INR")
	    public void usdToInr() throws InterruptedException {
	    	
	    	objHome.changeCurrency();
	    }
	    @Then("Currency is updated to INR")
	    public void verifyChangeCurrency() {
	    	String newCurr=objHome.verifyChangeCurrency();
	    	Assert.assertEquals("INR", newCurr);
	    	driver.quit();
	    }       
	   
	    @And("Agent clicks on My Bookings")
	    public void clickOnBookings() throws InterruptedException {
	    	objHome.verifyMyBookings();
	    	Thread.sleep(2000);
	    	
	    }
	    @Then("Agent directed to My Bookings page")
	    public void verifyBooking()  {
	    	String actTitle=driver.getTitle();
	    	String expTitle="Bookings - PHPTRAVELS";
	 	    Assert.assertEquals(actTitle,expTitle);
	  	    
	    }
	      
	    @And("Agent clicks on Add funds")
	    public void clickOnfunds() {
	    	objHome.verifyAddFunds();
	    	
	    }
	    @Then("Agent directed to Add funds page")
	    public void verifyFunds() {
	    	String exp="Add Funds - PHPTRAVELS";
		 	String act=driver.getTitle();
		 	Assert.assertEquals(exp, act);	
		 	driver.quit();
	    	
	    	
	    }
	  
	    @And("Agent clicks on My Profile")
	    public void clickOnProfile() {
	    	objHome.verifymyProfiles();
	    	
	    }
	    @Then("Agent directed to My Profile page")
	    public void verifyProfile() {
	    	String exp="Profile - PHPTRAVELS";
		 	String act=driver.getTitle();
		 	Assert.assertEquals(exp, act);	
		 	driver.quit();
	    	
	    }
	
	    @And("Agent clicks on Logout")
	    public void clickOnLogout() {
	    	objHome.verifymyLogout();
	    	
	    }
	    @Then("Agent directed to Login page")
	    public void verifyLogOut() {
	    	String exp="Login - PHPTRAVELS";
		 	String act=driver.getTitle();
		 	Assert.assertEquals(exp, act);	
		 	driver.quit();
	    }
	    
}
