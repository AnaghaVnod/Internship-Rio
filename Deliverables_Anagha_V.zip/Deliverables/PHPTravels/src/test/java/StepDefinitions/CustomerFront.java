package StepDefinitions;


import org.openqa.selenium.WebDriver;


import org.openqa.selenium.chrome.ChromeDriver;

import net.qa.utils.ExcelUtil;

import Customer_pages.AddFunds;
import Customer_pages.Bookings;
import Customer_pages.Dashboard;
import Customer_pages.Login;
import Customer_pages.Profile;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.IOException;

import org.junit.Assert;


public class CustomerFront {
	WebDriver driver=null;
	Login objLogin;
	Dashboard objDash;
	Bookings objBook;
	AddFunds objFunds;
	Profile objProf;



	@Given("User is on login page")
	public void loginPage() throws InterruptedException {

	     driver=new ChromeDriver();
	     driver.manage().window().maximize();
	     objLogin=new Login(driver);
	       objDash=new Dashboard(driver);
	       objBook=new Bookings(driver);
	       objFunds=new AddFunds(driver);
	       objProf=new Profile(driver);
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(1000);
	   
	}

	@When("^User enters valid username and valid password$")
	public void customerValid() throws IOException {

		objLogin.validDetails("user@phptravels.com","demouser");
	   
	}
	@When("^User enters \"([^\"]*)\" or \"([^\"]*)\"$")
	public void customerInvalidUser(String invalidusername,String invalidpassword) throws IOException {
		
	    objLogin.invalidDetails(invalidusername,invalidpassword);
	    
	    
	}

	
	@And("User clicks login")
	public void clickLogin() throws InterruptedException {
	
	    objLogin.clickLogin();
	       
	}

	
	@Then("User navigated to dashboard page")
	public void verifyLogin() throws InterruptedException {
	    Thread.sleep(1000);
	    String actual=driver.getTitle();
	    String expTitle="Dashboard - PHPTRAVELS";
	    Assert.assertEquals(expTitle, actual);
	    driver.quit();
	   
	}

    @Then("User not logged in")
	public void verifyError() {
    	String title=driver.getTitle();
    	String expected="Login - PHPTRAVELS";
        Assert.assertEquals(title,expected);
		driver.quit();
    }
		
	@When("User click on logout") 
	 	public void verifyMyLogout() {
	 		objDash.verifymyLogout();
	}
	 	
	@Then("User is navigated to login page")
	 	public void verifyLogout(){
	 	String exp="Login - PHPTRAVELS";
	 	String act=driver.getTitle();
	 	Assert.assertEquals(exp, act);	
	 	driver.quit();
	
    }
    @Given("User logged in")
       public void userLoggedin() throws InterruptedException {
    	driver=new ChromeDriver();
	     driver.manage().window().maximize();
	     objLogin=new Login(driver);
	       objDash=new Dashboard(driver);
	       objBook=new Bookings(driver);
	       objFunds=new AddFunds(driver);
	       objProf=new Profile(driver);
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(3000);
    	
       driver.navigate().to("https://phptravels.net/login");
	   objLogin.validDetails("user@phptravels.com","demouser");
	   objLogin.clickLogin();
	
    }
    
    @And("User clicks My Bookings")
       public void verifyMyBookings() throws InterruptedException {
 	   String actualTitle=objDash.verifyMyBookings();
 	   String expTitle="Bookings - PHPTRAVELS";
	   Assert.assertEquals(actualTitle,expTitle);
 	   Thread.sleep(2000);
 	   
    }
    
    @And("Details of bookings displayed")
       public void verifyBookings() {
 	   boolean actual=objBook.verifyBookings();
 	   boolean expect=true;
 	   Assert.assertEquals(expect, actual);
 	   
    }
    
    @When("User click on voucher of latest booking")
       public void clickViewVoucher() throws InterruptedException {
 	   objBook.clickVoucher();
 	   
    }
    @Then("Voucher is displayed")
       public void verifyVoucher() {
 	   objBook.verifyViewVoucher();
 	   driver.quit();
    }
    @And("User clicks add funds")
    public void addFunds() throws InterruptedException {
    	objDash.verifyAddFunds();
    	Thread.sleep(2000);
    }
    @When("User select Paypal for payment")
    public void payPal() {
    	objFunds.selectPaypal();
    	
    }
    @And("Add 50 USD in amount and proceed")
    public void addAmount() throws InterruptedException {
    	
    	objFunds.enterAmount("50");
    	objFunds.clickPayNow();
    	Thread.sleep(2000);
    
    	
    }
    @Then("Paypal window is displayed")
    public void  verifyPaypal() {
    	Boolean act=objFunds.verifyPaypalWindow();
    	Assert.assertTrue(act);
    	driver.quit();
    }
    
    @And("User clicks My Profile")
    public void verifyMyProfile() {
    	objDash.verifymyProfiles();
    }
    @When("User updates profile information")
    public void updateProfilInfo() throws IOException {

    	String firstName=ExcelUtil.getCellData(71, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String lastName=ExcelUtil.getCellData(72, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String phone=ExcelUtil.getCellData(73, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String email=ExcelUtil.getCellData(74, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String password=ExcelUtil.getCellData(75, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String country=ExcelUtil.getCellData(76, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String state=ExcelUtil.getCellData(77, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String city=ExcelUtil.getCellData(78, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String fax=ExcelUtil.getCellData(79, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String postal=ExcelUtil.getCellData(80, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String address1=ExcelUtil.getCellData(81, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	String address2=ExcelUtil.getCellData(82, 5,(System.getProperty("user.dir")+"\\src\\main\\resources\\Test_Case.xlsx"), 1);
    	objProf.enterFirstName(firstName);
    	objProf.enterLastName(lastName);
    	objProf.enterPhone(phone);
    	//objProf.enterEmail(email);
    	//objProf.enterPassword(password);
    	objProf.enterCountry(country);
    	objProf.enterState(state);
    	objProf.enterCity(city);
    	objProf.enterFax(fax);
    	objProf.enterPIN(postal);
    	objProf.enterAddress1(address1);
    	objProf.enterAddress2(address2);
    }
    @And("Clicks on Update profile")
    public void pressUpdate() {
    	objProf.clickUpdate();
    }
    @Then("Information is upadted")
    	public void verifyUpdate() {
    	
    		
    	}
}