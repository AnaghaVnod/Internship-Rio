package StepDefinitions;

import java.io.IOException;



import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import Admin_pages.AdminHome;
import Admin_pages.CancelledBookings;
import Admin_pages.PaidBookings;
import Admin_pages.PendingBookings;
import Customer_pages.Login;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminBack {
	WebDriver driver=null;
	Login objLogin;
	AdminHome objAdHome;
	Admin_pages.Bookings objBook;
	CancelledBookings objCan;
	PaidBookings objPaid;
	PendingBookings objPend;
	public volatile int c,nc;
	

	@Given("Admin is on login page")
		public void loginPage() throws InterruptedException {
		   
		  // System.setProperty("webdriver.chrome.driver", "C:\\Users\\anagh\\Downloads\\chromedriver_win32\\chromedriver.exe");
		   driver=new ChromeDriver(); 
		   driver.manage().window().maximize();	
		   driver.navigate().to("https://phptravels.net/admin");
		   Thread.sleep(3000);
		   objLogin=new Login(driver);
		   objAdHome=new AdminHome(driver);
	   }
	   
	   
	   
		   
	   @When("Admin enters valid username and valid password")
		public void adminValid() throws IOException, InterruptedException {
			objLogin.validDetails("admin@phptravels.com","demoadmin");
			Thread.sleep(2000);
			   
			}
	   @When("^Admin enters \"([^\"]*)\" or \"([^\"]*)\"$")
		public void adminInvalidUser(String invalidusername,String invalidpassword) throws IOException, InterruptedException {
				
			objLogin.invalidDetails(invalidusername,invalidpassword);
			Thread.sleep(2000);
	   }
	   @And("Admin clicks login")
		public void adminLogin() throws InterruptedException {
			objLogin.clickLogin();
			Thread.sleep(2000);
	   }
	   @Then("Admin navigated to dashboard page")
	   public void adminDashboard() {
		   
		    String title=driver.getTitle();
	    	String expected="Dashboard";
	        Assert.assertEquals(title,expected);
			driver.quit();  
	   }
	   @Then("Admin not logged in")
	   public void adminInvalid() throws InterruptedException {
		    String title=driver.getTitle();
	    	String expected="Administator Login";
	        Assert.assertEquals(expected,title);
	        Thread.sleep(3000);
			driver.quit();
		   
	   }
	   
	   @Given("Admin is on dashboard")
	   public void adminDash() throws InterruptedException {
		   driver=new ChromeDriver(); 
		   driver.manage().window().maximize();	
		   driver.navigate().to("https://phptravels.net/admin");
		   Thread.sleep(2000);
		   objLogin=new Login(driver);
		   objAdHome=new AdminHome(driver);
		   objLogin.validDetails("admin@phptravels.com","demoadmin");
		   objLogin.clickLogin();	
		   Thread.sleep(2000);
		   objBook=new Admin_pages.Bookings(driver);
		   objCan=new CancelledBookings(driver);
		   objPaid=new PaidBookings(driver);
		   objPend=new PendingBookings(driver);
	   }
	   @When("Admin clicks Bookings module")
	   public void verifyBooking() {
		   objAdHome.verfybookings();
		   
	   }
	   @And("Admin clicks on paid bookings")
	   public void clickPaidBook()  {
		   objBook.clickPaid();
		   
	   }
	   @When("Admin clicks on invoice")
	   public void verifyInvoice() throws InterruptedException {
		   objPaid.clickInvoice();
		   Thread.sleep(2000);
	   }
	   @Then("Invoice is displayed")
	   public void invoiceDisplay() {
		   String inv=objPaid.verifyInvoice();
		   String exp="Hotel Invoice - PHPTRAVELS";
		   Assert.assertEquals(exp, inv);
		   driver.quit();
	   }
	   
	   @And("Admin clicks on cancelled bookings")
	   public void cancelledBook() {
		   objBook.clickCancelled();
		    c=objCan.getNumCancelled();
	   }
	   @When("Admin delete a record")
	   public void deleteEntry() throws InterruptedException {
		   objCan.deleteBooking();
	   }
	   @Then("Count of cancelled bookings is updated")
	   public void updatedEntry() {
		    nc=objCan.newNumCancelled();
		    int nC=nc+1;
		   Assert.assertEquals(c,nC);
		   driver.quit();
			 	 
	   }
	   
	   @And("Admin clicks on pending bookings")
	   public void pendingBook() {
		   objAdHome.clickPend();
	   }
	   @When("Admin changes status pending to confirmed")
	   public void changeStatus() throws InterruptedException {
		   objPend.changeStatus("Confirmed");
		   
	   }
	   @Then("Count of bookings is updated")
	   public void updateCount() {
		   driver.quit();  
	   }
	   
	   @When("Admin click on website link")
	   public void verifyWebsite() throws InterruptedException {
		   objAdHome.clickWebsite();
		   Thread.sleep(2000);
	   }
	   @Then("Admin navigated to website window")
	   public void navigateWebsite() {
		   String web=objAdHome.verifyWebsite();
		   String exp="PHPTRAVELS | Travel Technology Partner - PHPTRAVELS";
		   Assert.assertEquals(exp, web);
		   driver.quit();
	   } 
	   
}
